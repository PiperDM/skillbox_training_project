from flask import Flask, request, render_template  # Подключить Фласк
from datetime import datetime
import json

# json.load - загрузить данные из файла
# json.dump - сохранить данные в файл

app = Flask(__name__)

MESSAGES_FILENAME = "messages_file.json"  # Имя файла с сообщениями

#  таблица замены символов для фильтрации XSS угроз
htmlEscapes = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
}


# функция замены (фильтрации) спецсимволов
def char_filter(target_string):
    for i, j in htmlEscapes.items():
        target_string = target_string.replace(i, j)
    return target_string


# Загружает сообщения из файла
def load_messages():
    # ДЗ1.
    # 1. Открыть файл
    # 2. Прочитать структуру данных из файла
    # 3. Взять сообщения из структуры

    message_file = open(MESSAGES_FILENAME, "r")
    data = json.load(message_file)
    return data["messages"]
    #  Альтернативный вариант: красивее, но не сам придумал :)
    # with open(MESSAGES_FILENAME, "r") as message_file:
    #    return json.load(message_file)["messages"]


all_messages = load_messages()


# Сохранять все сообщения в файл
def save_messages():
    # 1. Открыть файл
    message_file = open(MESSAGES_FILENAME, "w")
    # 2. Приготовить структуру данных
    data = {
        "messages": all_messages
    }
    # 3. Структуру данных записать в файл
    json.dump(data, message_file)


# Функция добавления нового сообщения
def add_message(sender, text):
    # проверить корректность длины
    if len(sender) < 3 or len(sender) > 100:
        return print("ERROR Nickname")

    if len(text) < 1 or len(text) > 30:
        return print("ERROR message text")

    text = char_filter(text)        # замена опасных символов
    sender = char_filter(sender)    # и еще раз

    # Создавать новое сообщение (новую структуру - словарь)
    new_message = {
        "text": text,
        "sender": sender,
        "time": datetime.now().strftime("%H:%M"),  # "часы:минуты"
    }
    # Добавлять сообщение в список
    all_messages.append(new_message)
    save_messages()


# Функция вывода всех сообщений - не используется
def print_all():
    for msg in all_messages:
        print_msg(msg)


# Функция печати одного сообщения
def print_msg(message):
    print(f'[{message["sender"]}]: {message["text"]} / {message["time"]}')



@app.route("/")
def main_page():
    return "Hello, welcome to SkillChatServer5000"


@app.route("/get_messages")
def get_messages():
    return {"messages": all_messages}


@app.route("/send_message")
def send_message():
    text = request.args["text"]  # ??
    name = request.args["name"]  # ??
    add_message(name, text)
    return "ok"


@app.route("/chat")
def chat():
    return render_template("form.html")  # Отображаем визуальный интерфейс из файла form.html


# Добавление сообщения
# UI: поля для ввода имени и текста и кнопки "отправить"


app.run()
